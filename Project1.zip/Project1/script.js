// Simple reviews carousel
(function () {
  const track = document.querySelector('.rc-track');
  const wrapper = document.querySelector('.rc-track-wrapper');
  const prev = document.querySelector('.rc-prev');
  const next = document.querySelector('.rc-next');
  if (!track || !wrapper || !prev || !next) return; // no carousel present

  const items = Array.from(track.children);
  let index = 0;
  let visibleCount = 4; // default
  let itemWidth = 0;
  let gap = 0;
  let autoplayTimer = null;

  function readStyles() {
    const style = getComputedStyle(track);
    gap = parseFloat(style.gap || 0);
    itemWidth = items[0]?.getBoundingClientRect().width || 0;
  }

  function updateVisible() {
    readStyles();
    const wrapW = wrapper.clientWidth;
    // compute number of items that fit
    visibleCount = Math.max(1, Math.floor(wrapW / (itemWidth + gap)));
    // clamp index
    index = Math.min(index, Math.max(0, items.length - visibleCount));
    moveToIndex(index);
  }

  function moveToIndex(i) {
    const wrapW = wrapper.clientWidth;
    const trackWidth = items.length * itemWidth + (items.length - 1) * gap;

    // center visible block inside wrapper by computing offset
    const visibleBlockWidth = visibleCount * itemWidth + Math.max(0, visibleCount - 1) * gap;
    const centerOffset = Math.max(0, (wrapW - visibleBlockWidth) / 2);

    const x = -(i * (itemWidth + gap)) + centerOffset;
    track.style.transform = `translateX(${x}px)`;
  }

  function prevSlide() {
    if (items.length <= visibleCount) return; // nothing to move
    if (index > 0) index -= 1; else index = Math.max(0, items.length - visibleCount); // wrap to end
    moveToIndex(index);
    resetAutoplay();
  }

  function nextSlide() {
    if (items.length <= visibleCount) return; // nothing to move
    if (index < items.length - visibleCount) index += 1; else index = 0; // wrap
    moveToIndex(index);
    resetAutoplay();
  }

  prev.addEventListener('click', prevSlide);
  next.addEventListener('click', nextSlide);

  // keyboard accessibility
  prev.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') prevSlide(); });
  next.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') nextSlide(); });

  // autoplay
  function startAutoplay() {
    autoplayTimer = setInterval(() => {
      nextSlide();
    }, 4500);
  }
  function resetAutoplay() {
    if (autoplayTimer) { clearInterval(autoplayTimer); }
    startAutoplay();
  }

  // recompute sizes on resize
  let resizeTimeout = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(updateVisible, 120);
  });

  // initial layout — wait for full load so images sizes are correct
  window.addEventListener('load', () => {
    updateVisible();
    startAutoplay();
  });

  // pause autoplay on hover and resume on leave
  const carousel = document.querySelector('.reviews-carousel');
  if (carousel) {
    carousel.addEventListener('mouseenter', () => { if (autoplayTimer) clearInterval(autoplayTimer); });
    carousel.addEventListener('mouseleave', () => { resetAutoplay(); });
  }
})();
